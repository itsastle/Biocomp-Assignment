#pragma once

#define POOL_SIZE 50

#define INPUT_LENGTH 7
#define RULE_LENGTH (INPUT_LENGTH+1)

#define NO_RULES 6
#define GENOME_LENGTH NO_RULES*RULE_LENGTH
#define DATA_LENGTH 64
#define NOTHING 5


typedef struct {

	int cmd[INPUT_LENGTH];
	int out;


}Rule;

typedef struct {

	int fitness;
	int genes[GENOME_LENGTH];
	Rule rules[NO_RULES];

}Individual;



typedef struct {

	Individual individuals[POOL_SIZE];
	float average_fitness;
	Individual best_individual;
	Individual prev_best_individual;
	int mutate_prob;



}Population;




// functions for population
void evaluate_population_fitness(Population* individuals,Rule* data);
void print_population(Population* population);
void perform_crossover(Individual* individuals);
void perform_mutation(Population* population);
void generate_population(Individual* individual);

void tournament(Population* population);
//functions for individuals
void evaluate_fitness(Individual* individual);
void print_individual(Individual* individual);
void mutate_individual(Individual* individual, int prob);

int get_best_index(Individual* individuals);
int get_worst_index(Individual* individuals);
void replace_worst(Population* population);
void calculate_rules(Individual* individuals);
int lookForRule(Rule* data, Rule* rules);
void print_rule_type(Individual* individual);
void print_population_rules(Individual* individuals);


void print_rule(Rule* rule);

void create_data(Rule* datafile);




