#include "genetics.h"
#include <math.h>
#include <stdio.h>
#pragma warning (disable:4996)
//functions for individuals
void generate_population(Individual* individual)
{
	
	for (int i = 0; i < POOL_SIZE; i++)
	{
		individual->fitness = 0;
		for (int b = 0; b < GENOME_LENGTH; b++)
		{
			individual->genes[b] = ((b+1)%RULE_LENGTH==0)? rand()%2 : rand()%3;
		}
		individual++;
	}


}

void print_population(Population* population)
{
	printf("-------Population-------------\n");
	Individual* individuals = population->individuals;
	for (int i = 0; i < POOL_SIZE; i++)
	{
		print_individual(individuals++);
	}
	printf("--------------------\n");
}

void create_data(Rule* datafile)
{

	char ch;
	FILE *fp;

	fp = fopen("data2.txt", "r"); // read mode

	int b = 0;

	char s[2];
	s[1] = '\0';

	ch = fgetc(fp);
	do {


		if (ch == '\n')
		{

			ch = fgetc(fp);
		}
		Rule* line = datafile++;
		for (int i = 0; i < INPUT_LENGTH; i++)
		{
			s[0] = ch;
			line->cmd[i] = atoi(s);
			ch = fgetc(fp);
		}
		ch = fgetc(fp);

		s[0] = ch;
		line->out = atoi(s);

	} while ((ch = fgetc(fp)) != EOF);

}

int get_best_index(Individual* individuals)
{
	int index = 0;
	for (int i = 1; i < POOL_SIZE; i++)
	{
		if (individuals[i].fitness > individuals[index].fitness)
			index = i;
	}

	return index;

}

int get_worst_index(Individual* individuals)
{
	int index = 0;
	for (int i = 1; i < POOL_SIZE; i++)
	{
		if (individuals[i].fitness < individuals[index].fitness)
			index = i;
	}

	return index;

}
void tournament(Population* population)
{
	Individual* individuals = population->individuals;
	int index = get_best_index(individuals);

	population->prev_best_individual = individuals[index];


	Individual temp[POOL_SIZE]; 

	for (int i = 0; i < POOL_SIZE; i++)
	{
		Individual a = individuals[rand() % POOL_SIZE];
		Individual b = individuals[rand() % POOL_SIZE];

		temp[i] = (a.fitness > b.fitness) ? a : b;

	}

	for (int i = 0; i < POOL_SIZE; i++)
	{
		individuals[i] = temp[i];
	}


}

void replace_worst(Population* population)
{
	int index = get_worst_index(population->individuals);

	population->individuals[index] = population->prev_best_individual;



}

void perform_crossover(Individual* individuals)
{
	int cross_point = 5;
	int temp;
	for (int i = 0; i < POOL_SIZE/2; i++)
	{
		cross_point = rand()%GENOME_LENGTH;
		Individual* a = individuals++;
		Individual* b = individuals++;
		
		for (int c= cross_point; c < GENOME_LENGTH; c++)
		{
			temp = a->genes[c];
			a->genes[c] = b->genes[c];
			b->genes[c] = temp;
		}

	}



}





void evaluate_population_fitness(Population* pop,Rule* data)
{
	calculate_rules(pop->individuals);
	
	
	float total_fitness = 0;
	Individual* individuals = pop->individuals;
	for (int i = 0; i < POOL_SIZE; i++)
	{
		evaluate_fitness(individuals,data);
		total_fitness += individuals->fitness;
		
		individuals++;
	}

	int index = get_best_index(pop->individuals);

	pop->best_individual = pop->individuals[index];


	float average = total_fitness/(POOL_SIZE*1.0);
	pop->average_fitness = average;
	

}

void calculate_rules(Individual* individuals)
{
	int bit = 0;
	for (int i = 0; i < POOL_SIZE; i++)
	{
		bit = 0;
		Rule* rules = individuals->rules;
		for (int j = 0; j < NO_RULES; j++)
		{
			for (int  b = 0; b < INPUT_LENGTH; b++)
			{
				rules[j].cmd[b] = individuals->genes[bit++];
			}
			rules[j].out = individuals->genes[bit++];
			

		}

		individuals++;

	}


}

void perform_mutation(Population* population)
{
	Individual* individual = population->individuals;
	for (int  i = 0; i < POOL_SIZE; i++)
	{
		mutate_individual(individual++, population->mutate_prob);
	}


}





void evaluate_fitness(Individual* individual,Rule* data)
{
	int sum = 0;
	int result;
	int fitness = 0;
	for (int i = 0; i < DATA_LENGTH; i++)
	{
		result = lookForRule(data, individual->rules);
		//printf("Output : %d\n", result);
		if (result == NOTHING)
		{
			fitness = 0;
			//printf("nothing\n");
		}
		else
		{
			fitness = (data->out == result)? 1:0;
			//printf("data %d  rule %d %s\n",data->out,result, (data->out == result) ? "true" : "False");
		}
		data++;
		sum += fitness;
	
	}

	individual->fitness = sum;


}

void print_population_rules(Individual* individuals)
{
	printf("--------Rules---------\n");
	for (int i = 0; i < POOL_SIZE; i++)
	{
		print_rule_type(individuals++);
	}
	printf("---------------------\n");

}

void print_rule_type(Individual* individual)
{
	printf("-----------------\n");
	for (int i = 0; i < NO_RULES; i++)
	{
		print_rule(&individual->rules[i]);
	}

	printf("-----------------\n");
}

void print_rule(Rule* rule)
{

	for (int b = 0; b < INPUT_LENGTH; b++)
	{
		printf("%d ", rule->cmd[b]);
	}

	printf("|%d| \n", rule->out);


}

int lookForRule(Rule* data,Rule* rules)
{
	int correct;
	for (int i = 0; i < NO_RULES; i++)
	{
		correct = 0;
		for (int b = 0; b < INPUT_LENGTH; b++)
		{
		
			if (rules->cmd[b] != 2 && rules->cmd[b] != data->cmd[b])
			{
				break;
			}
			else
			{

				correct += 1;
			}
		}

		if (correct == INPUT_LENGTH)
		{
			
			return rules->out;

		}

		rules++;
	}
	
	return NOTHING;


}

void print_individual(Individual* individual)
{
	
	for (int i = 0; i < GENOME_LENGTH; i++)
	{
		if (((i + 1)%RULE_LENGTH) == 0)
		{
			printf("|%d| ", individual->genes[i]);
			
		}else
		{
			printf("%d ", individual->genes[i]);
		}
		
	}
	printf(" Fitness : %d\n", individual->fitness);


}

void mutate_individual(Individual* individual, int prob)
{
	int valid[3][3] = { {1,2},{0,2},{0,1} };
	for (int  i = 0; i < GENOME_LENGTH; i++)
	{
		
		if (rand() % 100 < prob)
		{
			individual->genes[i] = (((i+1)%RULE_LENGTH ) == 0)  ? valid[individual->genes[i]][0]: valid[individual->genes[i]][rand() % 3];
		}
	}

}
