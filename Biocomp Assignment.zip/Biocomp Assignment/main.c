#include "genetics.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

//BIOCOMPUTATION ASSIGNMENT CODE/////
//29/11/2018///////////////
//KNOWN BUGS: BEST INDIVIDUAL ISNT STORED FOR SOME GENERATIONS (RARE///
//VERSION 0. 0. 2/////
//BY ASTLE MATHEW STUDENT NUMBER 15006173///


void main()
{
	srand(time(NULL));
	Population pop; 
	pop.mutate_prob = 0;//(1/((float)GENOME_LENGTH))*100;
	generate_population(pop.individuals);
	Rule datafile[DATA_LENGTH];
	int best[1500];
	int avg[1500];
	int count = 0;

	create_data(&datafile);

	for (int i = 0; i < DATA_LENGTH; i++)
	{
		print_rule(&datafile[i]);
	}
	
	evaluate_population_fitness(&pop, &datafile);//checks fitness of population
	while (pop.best_individual.fitness < 64)
	{
		tournament(&pop);		 //performs tournament selection and stores best individual in the population
		perform_crossover(pop.individuals);
		perform_mutation(&pop);
		
		evaluate_population_fitness(&pop, &datafile);		
		replace_worst(&pop); //finds the worst individual in the population and replaces it with the previously stored best
		count++;
		best[count] = pop.best_individual.fitness; //Stores every best individual into an array which can be displayed later
		avg[count] = pop.average_fitness; //stores every average fitness of population into array for later use
		system("cls");
		printf("Best fitness %d\n", pop.best_individual.fitness);
		printf("Avg fitness %.2f\n", pop.average_fitness);
		printf("Number of Generations: %d\n",count);
if (count == 1500) {
			break;
		}
	}

	print_rule_type(&pop.best_individual);
	for (int i = 1; i < count + 1; i++) {
		printf(" %d\n", best[i]);
	}
	printf("\n");
	for (int i = 1; i < count + 1; i++) {
		printf("%d\n", avg[i]);
	}
	getchar();

}